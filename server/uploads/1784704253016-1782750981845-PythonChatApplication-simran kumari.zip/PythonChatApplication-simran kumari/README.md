 # Python Chat Application

## Description
This project is a simple, real-time chat application built using Python **Socket Programming** and **Tkinter (GUI)**. It enables smooth, two-way communication between a client and a server using a multithreaded architecture.

## Features
* **Server-Client Architecture:** Server listens on a dedicated port while the client safely establishes a TCP connection.
* **Two-Way Communication:** Real-time messages can be sent and received simultaneously from both sides.
* **Graphical User Interface (GUI):** A clean Tkinter layout that shows separate chat windows for the server and client.
* **Robust Error Handling:** Handles cases where the server is offline or connection drops unexpectedly.

## Project Structure
* `server.py` — Handles server-side socket communication, listens for connection, and handles incoming/outgoing data.
* `client.py` — Handles client-side connection setup and connects to the server.
* `layout.py` — Defines the reusable Tkinter chat window interface structure.
* `main.py` — The introduction entry file explaining project execution instructions.

## Requirements
* Python 3.x

## How to Run

### Step 1: Start the Server
Open your terminal and run the server file first so it can start listening:
```bash
python server.py
### step2: start the client
python client