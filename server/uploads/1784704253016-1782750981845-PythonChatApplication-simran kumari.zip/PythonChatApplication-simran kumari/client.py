import socket
import threading
from layout import ChatWindow

def start_client():
    host = '127.0.0.1'
    port = 6500

    # 1. Socket Create karna
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    window = None

    # Server ko message bhejne ka function
    def send_to_server(message):
        try:
            client_socket.send(message.encode('utf-8'))
            window.display_message(f"Client (You): {message}")
        except:
            window.display_message("[System: Server ko message nahi bheja ja saka]")

    window = ChatWindow("Client Window", send_to_server)

    # Background mein connect karne aur message receive karne ka function
    def connect_and_receive():
        try:
            window.display_message("[System: Server se connect ho rahe hain...]")
            client_socket.connect((host, port))
            window.display_message("[System: Server se successfully connect ho gaye!]")
            
            while True:
                try:
                    server_reply = client_socket.recv(1024).decode('utf-8')
                    if not server_reply:
                        window.display_message("[System: Server band ho gaya]")
                        break
                    window.display_message(f"Server: {server_reply}")
                except:
                    break
        except ConnectionRefusedError:
            window.display_message("[Error: Server chalu nahi hai! Pehle server.py chalao]")

    # Window close hone par socket band karne ke liye
    def on_closing():
        try:
            client_socket.close()
        except:
            pass
        window.root.destroy()

    window.root.protocol("WM_DELETE_WINDOW", on_closing)

    # Background thread shuru karna
    threading.Thread(target=connect_and_receive, daemon=True).start()
    window.start()

if __name__ == "__main__":
    start_client()