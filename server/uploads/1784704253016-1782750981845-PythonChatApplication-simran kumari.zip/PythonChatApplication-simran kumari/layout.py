import tkinter as tk

class ChatWindow:
    def __init__(self, title, send_callback):
        self.root = tk.Tk()
        self.root.title(title)
        self.root.geometry("360x480")
        
        self.text_area = tk.Text(self.root, height=20, width=42, font=("Arial", 10))
        self.text_area.pack(pady=15, padx=10)
        self.text_area.config(state=tk.DISABLED)

        self.entry_box = tk.Entry(self.root, width=32, font=("Arial", 11))
        self.entry_box.pack(pady=5)
        self.entry_box.focus()

        self.send_callback = send_callback

        self.send_btn = tk.Button(self.root, text="Send", width=12, bg="#e1e1e1", command=self.send_message)
        self.send_btn.pack(pady=10)

        self.root.bind('<Return>', lambda event: self.send_message())

    def display_message(self, message):
        self.text_area.config(state=tk.NORMAL)
        self.text_area.insert(tk.END, message + "\n")
        self.text_area.config(state=tk.DISABLED)
        self.text_area.yview(tk.END)

    def send_message(self):
        msg = self.entry_box.get()
        if msg.strip():
            self.send_callback(msg)
            self.entry_box.delete(0, tk.END)

    def start(self):
        self.root.lift()
        self.root.attributes('-topmost', True)
        self.root.after(1, lambda: self.root.attributes('-topmost', False))
        self.root.mainloop()