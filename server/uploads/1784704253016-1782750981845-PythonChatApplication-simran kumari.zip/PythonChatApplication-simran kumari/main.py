from layout import ChatWindow

def main():
    print("="*40)
    print("     PYTHON CHAT APPLICATION")
    print("="*40)
    print("\nHow to run this project:")
    print("1. Open a terminal and run: python server.py")
    print("2. Open another terminal and run: python client.py")
    print("\nNote: Make sure to run the server first so the client can connect!")
    print("="*40)

if __name__ == "__main__":
    main()