import socket
import threading
from layout import ChatWindow

def start_server():
    host = '127.0.0.1'
    port = 6500 

    # 1. Socket Create karna
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Yeh line error se bachati hai agar port pehle se busy ho
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    # 2. Bind aur Listen karna
    server_socket.bind((host, port))
    server_socket.listen(1)
    print("Server chalu ho gaya hai... Connection ka wait ho raha hai...")

    client_socket = None

    # Message bhejne ka function
    def send_to_client(message):
        if client_socket:
            try:
                client_socket.send(message.encode('utf-8'))
                window.display_message(f"Server (You): {message}")
            except:
                window.display_message("[System: Client se connection toot gaya]")
        else:
            window.display_message("[System: Abhi tak koi client connect nahi hua]")

    # GUI Window create karna
    window = ChatWindow("Server Window", send_to_client)
    window.display_message("[System: Client ke connect hone ka wait kar rahe hain...]")

    # Background mein client ko accept karne wala function
    def accept_connections():
        nonlocal client_socket
        try:
            client_socket, addr = server_socket.accept()
            print(f"Client connect ho gaya: {addr}")
            window.display_message(f"[System: Client {addr} se connect ho gaya!]")
            
            # Client se message receive karne ka loop
            while True:
                try:
                    client_message = client_socket.recv(1024).decode('utf-8')
                    if not client_message:
                        window.display_message("[System: Client ne chat band kar di]")
                        break
                    window.display_message(f"Client: {client_message}")
                except:
                    break
        except:
            pass

    # Safe exit ke liye function jab window close ho
    def on_closing():
        try:
            if client_socket: client_socket.close()
            server_socket.close()
        except:
            pass
        window.root.destroy()

    window.root.protocol("WM_DELETE_WINDOW", on_closing)

    # Threading use kar rahe hain taaki GUI freeze na ho
    threading.Thread(target=accept_connections, daemon=True).start()
    window.start()

if __name__ == "__main__":
    start_server()