const wrapper = document.querySelector(".qr-wrapper");
const qrInput = document.getElementById("qr-text");
const qrFile = document.getElementById("qr-file");
const generateBtn = document.getElementById("generate-btn");
const btnText = document.getElementById("btn-text");
const btnSpinner = document.querySelector(".btn-spinner");
const qrCodeBox = document.getElementById("qr-code");
const downloadBtn = document.getElementById("download-btn");

const tabText = document.getElementById("tab-text");
const tabImage = document.getElementById("tab-image");
const textInputWrapper = document.getElementById("text-input-wrapper");
const imageInputWrapper = document.getElementById("image-input-wrapper");
const fileNameSpan = document.getElementById("file-name");
const infoText = document.getElementById("info-text");

let isImageMode = false;
let qrCode = null;

// Custom Toast Notification
function showToast(message, type = "info") {
    const toast = document.getElementById("toast");
    const icons = {
        success: '<i class="fa-solid fa-circle-check success"></i>',
        error: '<i class="fa-solid fa-circle-xmark error"></i>',
        info: '<i class="fa-solid fa-circle-info info"></i>'
    };
    
    toast.innerHTML = `${icons[type]} <span>${message}</span>`;
    toast.classList.add("show");
    
    setTimeout(() => {
        toast.classList.remove("show");
    }, 3000);
}

function setLoading(isLoading, text = "Generate QR") {
    generateBtn.disabled = isLoading;
    if (isLoading) {
        btnText.innerText = text;
        btnSpinner.classList.remove("hidden");
    } else {
        btnText.innerText = text;
        btnSpinner.classList.add("hidden");
    }
}

// File Name Update
qrFile.addEventListener("change", (e) => {
    if (e.target.files.length > 0) {
        let name = e.target.files[0].name;
        if (name.length > 25) name = name.substring(0, 25) + "...";
        fileNameSpan.innerText = name;
        fileNameSpan.style.color = "#6c5ce7";
    } else {
        fileNameSpan.innerText = "Browse Image to Upload";
        fileNameSpan.style.color = "";
    }
});

// Tab Switching
tabText.addEventListener("click", () => {
    isImageMode = false;
    tabText.classList.add("active");
    tabImage.classList.remove("active");
    textInputWrapper.style.display = "block";
    imageInputWrapper.style.display = "none";
    infoText.innerText = "Enter any URL or text to generate a scannable QR code.";
});

tabImage.addEventListener("click", () => {
    isImageMode = true;
    tabImage.classList.add("active");
    tabText.classList.remove("active");
    textInputWrapper.style.display = "none";
    imageInputWrapper.style.display = "block";
    infoText.innerText = "Securely turn your image into a cloud link & scannable QR code.";
});

function createQR(data) {
    setLoading(true, "Generating...");
    qrCodeBox.innerHTML = "";

    try {
        qrCode = new QRCode(qrCodeBox, {
            text: data,
            width: 170,
            height: 170,
            colorDark: "#1f1c2c",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.M
        });

        setTimeout(() => {
            wrapper.classList.add("active");
            setLoading(false, "Generate QR");
            showToast("QR Code generated successfully!", "success");

            const qrCanvas = qrCodeBox.querySelector("canvas");
            if (qrCanvas) {
                const imgData = qrCanvas.toDataURL("image/png");
                downloadBtn.href = imgData;
                downloadBtn.classList.remove("disabled");
            }
        }, 500);
    } catch (err) {
        showToast("Error generating QR code", "error");
        setLoading(false, "Generate QR");
    }
}

// Uploads image to ImgBB to get a public URL
async function uploadImageAndGenerateQR(file) {
    setLoading(true, "Uploading...");

    // You can get a free API key by signing up at https://api.imgbb.com/
    // Place your API Key here:
    const IMGBB_API_KEY = "2df75df6cb7cb5cdb3e7172cf68eec08";

    const formData = new FormData();
    formData.append("image", file);

    try {
        const response = await fetch(`https://api.imgbb.com/1/upload?key=${IMGBB_API_KEY}`, {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.success) {
            const imageUrl = data.data.url;
            console.log("Image uploaded to:", imageUrl);
            // Now generate a QR code for the Live Image URL
            createQR(imageUrl);
        } else {
            const errorMsg = data.error ? data.error.message : "Unknown error";
            showToast(`Upload failed: ${errorMsg}`, "error");
            setLoading(false, "Generate QR");
        }
    } catch (error) {
        console.error("Upload error:", error);
        showToast("Upload failed. Check your connection or API key.", "error");
        setLoading(false, "Generate QR");
    }
}

generateBtn.addEventListener("click", () => {
    if (isImageMode) {
        const file = qrFile.files[0];
        if (!file) {
            showToast("Please browse an image first", "error");
            return;
        }

        // Upload the image to a server to get a URL, then create QR
        uploadImageAndGenerateQR(file);

    } else {
        let qrValue = qrInput.value.trim();
        if (!qrValue) {
            showToast("Please enter a valid link or text", "error");
            qrInput.classList.add("error");
            setTimeout(() => qrInput.classList.remove("error"), 1000);
            return;
        }
        createQR(qrValue);
    }
});

// Reset UI if user clears text input
qrInput.addEventListener("keyup", () => {
    if (!qrInput.value.trim()) {
        wrapper.classList.remove("active");
        downloadBtn.classList.add("disabled");
        downloadBtn.removeAttribute("href");
        qrCodeBox.innerHTML = "";
    }
});